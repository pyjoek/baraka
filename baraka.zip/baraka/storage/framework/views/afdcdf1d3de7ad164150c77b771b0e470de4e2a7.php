<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <title>Document</title>
    <style>
        .date-row {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .date-item {
            margin: 10px;
        }
        .content {
            display: none;
        }
        h1 a {
            margin-right: 20px;
        }
        table th, table td {
            text-align: center;
            vertical-align: middle;
        }
        table {
            margin-top: 20px;
            border: 1px solid #ddd;
        }
        .btn-primary {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <main>
        <center>
            <h1>
                <a href="/adat" class="btn btn-link">Add New Attendance</a>&nbsp;&nbsp;&nbsp;
                <a href="/add" class="btn btn-link">Add New Student</a>&nbsp;&nbsp;&nbsp;
                <a href="/dates" class="btn btn-link">Dates</a>&nbsp;&nbsp;&nbsp;
                <a href="/logout" class="btn btn-link">Logout</a>
            </h1>

            <!-- Displaying table buttons -->
            <div class="date-row">
                <?php $__currentLoopData = $dateTables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="date-item">
                        <button onclick="showContent(<?php echo e($index); ?>)" class="btn btn-primary"><?php echo e($table['table_name']); ?></button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Displaying content for each table -->
            <?php $__currentLoopData = $dateTables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="content-<?php echo e($index); ?>" class="content container">
                    <h3>Table: <?php echo e($table['table_name']); ?></h3>
                    
                    <h4>Sample Data:</h4>
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <?php $__currentLoopData = $table['columns']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($column->Field); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $table['sample_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $__currentLoopData = $table['columns']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td>
                                            
                                            <?php echo e(is_array($row->{$column->Field}) || is_object($row->{$column->Field}) ? json_encode($row->{$column->Field}) : strval($row->{$column->Field})); ?>

                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </center>
    </main>

    <script>
        function showContent(index) {
            // Hide all content
            let contents = document.querySelectorAll('.content');
            contents.forEach(function(content) {
                content.style.display = 'none';
            });

            // Show the selected content
            let selectedContent = document.getElementById('content-' + index);
            selectedContent.style.display = 'block';
        }
    </script>
</body>
</html>
<?php /**PATH /home/dragon/Documents/Laravel/baraka/resources/views/dates.blade.php ENDPATH**/ ?>